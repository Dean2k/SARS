﻿using UnityEditor;

namespace VRC.Udon.Editor.ProgramSources
{
    [CustomEditor(typeof(UdonAssemblyProgramAsset))]
    public class UdonAssemblyProgramAssetEditor : UdonProgramAssetEditor
    {
    }
}
