﻿namespace VRC.SDKBase.Editor.Api
{
    public interface IVRCContent
    {
        string Name { get; set; }
    }
}